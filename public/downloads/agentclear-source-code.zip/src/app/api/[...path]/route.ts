import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { AgentExecutionConfig, DEFAULT_BODY_TEMPLATE, executeRun, executeTurn, renderTemplate } from "@/lib/engine";
import { SESSION_COOKIE, SsrfError, agentInputSchema, assertSafeHttpUrl, audit, clientIp, createSession, db, destroyAllSessions, destroyCurrentSession, encryptSecret, getAuth, hashPassword, jsonError, jsonOk, loadSuiteDetail, mapAgentRow, mapCaseRow, mapRunDetail, mapRunSummary, randomToken, rateLimit, readSessionToken, requestUserAgent, requireReadOnlyContext, requireSession, requireWorkspaceContext, seedWorkspace, sessionCookieOptions, sha256Hex, suiteInputSchema, testCaseInputSchema, verifyPassword } from "@/lib/server";
import { CompareDTO, ConnectionTestResultDTO, OverviewDTO, ResultStatus } from "@/lib/types";

/* ========================================================================== */
/* from src/app/api/auth/login/route.ts (/auth/login) */
/* ========================================================================== */

const schema_auth_login = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  password: z.string().min(1, "Password is required."),
});

async function auth_login_POST(request: NextRequest) {
  const ip = clientIp(request);
  const rl = rateLimit(`login:${ip}`, 15, 15 * 60 * 1000);
  if (!rl.ok) {
    return jsonError(
      `Too many sign-in attempts. Try again in ${rl.retryAfterSec}s.`,
      429
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_auth_login.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const { email, password } = parsed.data;

  const user = await db.user.findUnique({
    where: { email },
    include: { memberships: { include: { workspace: true }, orderBy: { createdAt: "asc" } } },
  });
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return jsonError("Incorrect email or password.", 401);
  }

  const { token, expiresAt } = await createSession(
    user.id,
    await requestUserAgent()
  );
  await audit("auth.login", { email }, { userId: user.id });

  const res = NextResponse.json({
    user: { id: user.id, email: user.email, name: user.name },
    workspaces: user.memberships.map((m) => ({
      id: m.workspaceId,
      name: m.workspace.name,
      role: m.role,
      createdAt: m.workspace.createdAt.toISOString(),
    })),
    currentWorkspaceId: user.memberships[0]?.workspaceId ?? null,
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return res;
}


/* ========================================================================== */
/* from src/app/api/auth/logout/route.ts (/auth/logout) */
/* ========================================================================== */

async function auth_logout_POST(request: NextRequest) {
  const auth = await getAuth();
  await destroyCurrentSession();
  if (auth) await audit("auth.logout", {}, { userId: auth.userId });
  const res = NextResponse.json({ ok: true });
  res.cookies.set(SESSION_COOKIE, "", { path: "/", expires: new Date(0) });
  return res;
}


/* ========================================================================== */
/* from src/app/api/auth/session/route.ts (/auth/session) */
/* ========================================================================== */

async function auth_session_GET(request: NextRequest) {
  const auth = await getAuth();
  if (!auth) {
    return NextResponse.json(
      { user: null, workspaces: [], currentWorkspaceId: null },
      { headers: { "Cache-Control": "no-store" } }
    );
  }
  const memberships = await db.membership.findMany({
    where: { userId: auth.userId },
    include: { workspace: true },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json(
    {
      user: { id: auth.userId, email: auth.email, name: auth.name },
      workspaces: memberships.map((m) => ({
        id: m.workspaceId,
        name: m.workspace.name,
        role: m.role,
        createdAt: m.workspace.createdAt.toISOString(),
      })),
      currentWorkspaceId: memberships[0]?.workspaceId ?? null,
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}


/* ========================================================================== */
/* from src/app/api/auth/signup/route.ts (/auth/signup) */
/* ========================================================================== */

const schema_auth_signup = z.object({
  name: z.string().trim().min(1, "Name is required.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters.")
    .max(200),
});

async function auth_signup_POST(request: NextRequest) {
  const ip = clientIp(request);
  const rl = rateLimit(`signup:${ip}`, 10, 60 * 60 * 1000);
  if (!rl.ok) {
    return jsonError("Too many sign-up attempts. Try again later.", 429);
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_auth_signup.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const { name, email, password } = parsed.data;

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return jsonError("An account with this email already exists.", 409);
  }

  const workspaceName = `${name.split(" ")[0]}'s Workspace`;
  const user = await db.user.create({
    data: {
      email,
      name,
      passwordHash: hashPassword(password),
      memberships: {
        create: {
          workspace: { create: { name: workspaceName } },
          role: "OWNER",
        },
      },
    },
    include: { memberships: { include: { workspace: true } } },
  });

  const membership = user.memberships[0];
  await seedWorkspace(membership.workspaceId, user.id, user.name);
  await audit(
    "workspace.created",
    { workspaceName, seeded: true },
    { workspaceId: membership.workspaceId, userId: user.id }
  );

  const { token, expiresAt } = await createSession(
    user.id,
    await requestUserAgent()
  );
  await audit("auth.signup", { email }, { userId: user.id });

  const res = NextResponse.json({
    user: { id: user.id, email: user.email, name: user.name },
    workspaces: [
      {
        id: membership.workspaceId,
        name: membership.workspace.name,
        role: membership.role,
        createdAt: membership.workspace.createdAt.toISOString(),
      },
    ],
    currentWorkspaceId: membership.workspaceId,
  });
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return res;
}


/* ========================================================================== */
/* from src/app/api/agents/route.ts (/agents) */
/* ========================================================================== */

async function agents_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const agents = await db.agent.findMany({
    where: { workspaceId: guard.ctx.workspaceId },
    orderBy: { createdAt: "asc" },
  });
  return jsonOk({ agents: agents.map(mapAgentRow) });
}

async function agents_POST(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = agentInputSchema.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  if (input.type === "CUSTOM_HTTP") {
    if (!input.endpointUrl) {
      return jsonError("An endpoint URL is required for HTTP agents.", 422);
    }
    try {
      await assertSafeHttpUrl(input.endpointUrl);
    } catch (e) {
      return jsonError(e instanceof SsrfError ? e.message : "The endpoint URL is not allowed.", 422);
    }
  }

  const secretCiphertext =
    input.secret && input.secret.length > 0 ? encryptSecret(input.secret) : null;

  const agent = await db.agent.create({
    data: {
      workspaceId: ctx.workspaceId,
      name: input.name,
      description: input.description ?? "",
      type: input.type,
      endpointUrl: input.type === "DEMO_SANDBOX" ? null : input.endpointUrl!,
      method: input.type === "DEMO_SANDBOX" ? "POST" : input.method,
      headersJson: JSON.stringify(input.headers ?? {}),
      bodyTemplate: input.bodyTemplate ?? DEFAULT_BODY_TEMPLATE,
      responseField: input.responseField ?? "reply",
      toolCallsField: input.toolCallsField ?? "tool_calls",
      authType: input.authType ?? "NONE",
      authHeaderName: input.authHeaderName ?? null,
      secretCiphertext,
      timeoutMs: input.timeoutMs ?? 15000,
      expectedContentType: input.expectedContentType ?? "JSON",
      status: input.status ?? "ACTIVE",
    },
  });

  await audit(
    "agent.created",
    { agentId: agent.id, name: agent.name, type: agent.type },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk({ agent: mapAgentRow(agent) }, { status: 201 });
}


/* ========================================================================== */
/* from src/app/api/agents/[id]/route.ts (/agents/[id]) */
/* ========================================================================== */

async function agents_id_GET(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const agent = await db.agent.findFirst({
    where: { id, workspaceId: guard.ctx.workspaceId },
  });
  if (!agent) return jsonError("Agent not found.", 404);
  return jsonOk({ agent: mapAgentRow(agent) });
}

async function agents_id_PATCH(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const agent = await db.agent.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!agent) return jsonError("Agent not found.", 404);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = agentInputSchema.partial().safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  const type = input.type ?? (agent.type as "DEMO_SANDBOX" | "CUSTOM_HTTP");
  const endpointUrl =
    input.endpointUrl !== undefined ? input.endpointUrl : agent.endpointUrl;

  if (type === "CUSTOM_HTTP") {
    if (!endpointUrl) {
      return jsonError("An endpoint URL is required for HTTP agents.", 422);
    }
    if (input.endpointUrl && input.endpointUrl !== agent.endpointUrl) {
      try {
        await assertSafeHttpUrl(input.endpointUrl);
      } catch (e) {
        return jsonError(
          e instanceof SsrfError ? e.message : "The endpoint URL is not allowed.",
          422
        );
      }
    }
  }

  const data: Record<string, unknown> = {};
  if (input.name !== undefined) data.name = input.name;
  if (input.description !== undefined) data.description = input.description;
  if (input.type !== undefined) data.type = input.type;
  if (input.endpointUrl !== undefined)
    data.endpointUrl = type === "DEMO_SANDBOX" ? null : input.endpointUrl;
  if (input.method !== undefined) data.method = input.method;
  if (input.headers !== undefined) data.headersJson = JSON.stringify(input.headers);
  if (input.bodyTemplate !== undefined) data.bodyTemplate = input.bodyTemplate;
  if (input.responseField !== undefined) data.responseField = input.responseField;
  if (input.toolCallsField !== undefined) data.toolCallsField = input.toolCallsField;
  if (input.authType !== undefined) data.authType = input.authType;
  if (input.authHeaderName !== undefined) data.authHeaderName = input.authHeaderName;
  if (input.timeoutMs !== undefined) data.timeoutMs = input.timeoutMs;
  if (input.expectedContentType !== undefined)
    data.expectedContentType = input.expectedContentType;
  if (input.status !== undefined) data.status = input.status;
  if (input.secret !== undefined) {
    data.secretCiphertext =
      input.secret && input.secret.length > 0 ? encryptSecret(input.secret) : null;
  }
  // config changes invalidate the last connection result
  if (
    input.endpointUrl !== undefined ||
    input.headers !== undefined ||
    input.bodyTemplate !== undefined ||
    input.responseField !== undefined ||
    input.toolCallsField !== undefined ||
    input.authType !== undefined ||
    (input.secret !== undefined && (input.secret?.length ?? 0) > 0)
  ) {
    data.connectionStatus = "UNKNOWN";
    data.lastTestedAt = null;
    data.lastTestResultJson = null;
  }

  const updated = await db.agent.update({
    where: { id: agent.id },
    data,
  });
  await audit(
    "agent.updated",
    { agentId: agent.id, fields: Object.keys(data) },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  return jsonOk({ agent: mapAgentRow(updated) });
}

async function agents_id_DELETE(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;
  const agent = await db.agent.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!agent) return jsonError("Agent not found.", 404);

  // prevent deletion while runs are executing against it
  const activeRuns = await db.testRun.count({
    where: { agentId: agent.id, status: { in: ["QUEUED", "RUNNING"] } },
  });
  if (activeRuns > 0) {
    return jsonError(
      "This agent has runs in progress. Cancel them or wait for completion before deleting the agent.",
      409
    );
  }

  await db.agent.delete({ where: { id: agent.id } });
  await audit(
    "agent.deleted",
    { agentId: agent.id, name: agent.name },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* from src/app/api/agents/[id]/test/route.ts (/agents/[id]/test) */
/* ========================================================================== */

/**
 * Connection test — validates the agent configuration end-to-end with a
 * harmless greeting message before any real test run is allowed to start.
 * For the sandbox agent this performs no network I/O at all.
 */
async function agents_id_test_POST(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const agent = await db.agent.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!agent) return jsonError("Agent not found.", 404);
  if (agent.status === "DISABLED") {
    return jsonError("This agent connection is disabled. Enable it first.", 409);
  }

  const config: AgentExecutionConfig = {
    type: agent.type,
    endpointUrl: agent.endpointUrl,
    method: agent.method,
    headersJson: agent.headersJson,
    bodyTemplate: agent.bodyTemplate || DEFAULT_BODY_TEMPLATE,
    responseField: agent.responseField,
    toolCallsField: agent.toolCallsField,
    authType: agent.authType,
    authHeaderName: agent.authHeaderName,
    secretCiphertext: agent.secretCiphertext,
    timeoutMs: Math.min(agent.timeoutMs, 20000),
    expectedContentType: agent.expectedContentType,
  };

  const sessionId = `connection-test-${agent.id.slice(-8)}`;
  const message = "Hello, this is a connection test from AgentClear.";
  const rendered = renderTemplate(config.bodyTemplate, {
    session_id: sessionId,
    message,
    history_json: JSON.stringify([{ role: "user", content: message }]),
    turn: "0",
  });

  const turn = await executeTurn(config, rendered);

  let ok = !turn.error;
  let error: string | undefined = turn.error ?? undefined;
  if (ok && turn.reply === null) {
    ok = false;
    error = `The response was received (HTTP ${turn.statusCode}) but the reply could not be extracted using the configured response field ("${agent.responseField || "reply"}").`;
  }

  const result: ConnectionTestResultDTO = {
    ok,
    statusCode: turn.statusCode || undefined,
    durationMs: turn.durationMs,
    replyPreview: turn.reply?.slice(0, 400) ?? undefined,
    error,
    testedAt: new Date().toISOString(),
  };

  await db.agent.update({
    where: { id: agent.id },
    data: {
      connectionStatus: ok ? "CONNECTED" : "FAILED",
      lastTestedAt: new Date(),
      lastTestResultJson: JSON.stringify(
        agent.type === "DEMO_SANDBOX"
          ? { ...result, note: "Internal sandbox — no network request was made." }
          : result
      ),
    },
  });
  await audit(
    "agent.connection_test",
    { agentId: agent.id, ok, statusCode: turn.statusCode },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk({ result });
}


/* ========================================================================== */
/* from src/app/api/suites/route.ts (/suites) */
/* ========================================================================== */

const createSchema_suites = suiteInputSchema.extend({
  cases: z.array(testCaseInputSchema).max(200).optional(),
});

async function suites_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const suites = await db.testSuite.findMany({
    where: { workspaceId: guard.ctx.workspaceId },
    include: { _count: { select: { cases: true } } },
    orderBy: [{ isStarter: "desc" }, { createdAt: "asc" }],
  });
  return jsonOk({
    suites: suites.map((s) => ({
      id: s.id,
      name: s.name,
      description: s.description,
      isStarter: s.isStarter,
      caseCount: s._count.cases,
      createdAt: s.createdAt.toISOString(),
      updatedAt: s.updatedAt.toISOString(),
    })),
  });
}

async function suites_POST(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = createSchema_suites.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  const suite = await db.testSuite.create({
    data: {
      workspaceId: ctx.workspaceId,
      name: input.name,
      description: input.description ?? "",
      tagsCsv: (input.tags ?? []).join(","),
      isStarter: false,
      cases:
        input.cases && input.cases.length > 0
          ? {
              create: input.cases.map((c, i) => ({
                displayId: c.displayId,
                orderIndex: i + 1,
                category: c.category,
                severity: c.severity,
                title: c.title,
                description: c.description ?? "",
                turnsJson: JSON.stringify(c.turns),
                expectedBehavior: c.expectedBehavior,
                evidenceNote: c.evidence ?? "",
                rulesJson: JSON.stringify(c.rules ?? []),
                failureHint: c.failureHint ?? null,
                tagsCsv: (c.tags ?? []).join(","),
              })),
            }
          : undefined,
    },
    include: { _count: { select: { cases: true } } },
  });

  await audit(
    "suite.created",
    { suiteId: suite.id, name: suite.name, cases: suite._count.cases },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk(
    {
      suite: {
        id: suite.id,
        name: suite.name,
        description: suite.description,
        isStarter: false,
        caseCount: suite._count.cases,
        createdAt: suite.createdAt.toISOString(),
        updatedAt: suite.updatedAt.toISOString(),
      },
    },
    { status: 201 }
  );
}


/* ========================================================================== */
/* from src/app/api/suites/[id]/route.ts (/suites/[id]) */
/* ========================================================================== */

async function suites_id_GET(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const suite = await loadSuiteDetail(id, guard.ctx.workspaceId);
  if (!suite) return jsonError("Test suite not found.", 404);
  return jsonOk({ suite });
}

async function suites_id_PATCH(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = suiteInputSchema.partial().safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  const updated = await db.testSuite.update({
    where: { id: suite.id },
    data: {
      ...(input.name !== undefined ? { name: input.name } : {}),
      ...(input.description !== undefined ? { description: input.description } : {}),
      ...(input.tags !== undefined ? { tagsCsv: input.tags.join(",") } : {}),
    },
  });
  await audit(
    "suite.updated",
    { suiteId: suite.id, fields: Object.keys(input) },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  const detail = await loadSuiteDetail(updated.id, ctx.workspaceId);
  return jsonOk({ suite: detail });
}

async function suites_id_DELETE(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;
  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  const activeRuns = await db.testRun.count({
    where: { suiteId: suite.id, status: { in: ["QUEUED", "RUNNING"] } },
  });
  if (activeRuns > 0) {
    return jsonError(
      "This suite has runs in progress. Cancel them or wait for completion before deleting the suite.",
      409
    );
  }

  // Runs are preserved (agent/suite relations are set-null) so historical
  // reports stay intact.
  await db.testSuite.delete({ where: { id: suite.id } });
  await audit(
    "suite.deleted",
    { suiteId: suite.id, name: suite.name },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* from src/app/api/suites/[id]/cases/route.ts (/suites/[id]/cases) */
/* ========================================================================== */

/** Add a test case to a suite. */
async function suites_id_cases_POST(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
    include: { _count: { select: { cases: true } } },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = testCaseInputSchema.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  const duplicate = await db.testCase.findFirst({
    where: { suiteId: suite.id, displayId: input.displayId },
  });
  if (duplicate) {
    return jsonError(
      `Case id "${input.displayId}" already exists in this suite.`,
      409
    );
  }

  const maxOrder = await db.testCase.aggregate({
    where: { suiteId: suite.id },
    _max: { orderIndex: true },
  });

  const created = await db.testCase.create({
    data: {
      suiteId: suite.id,
      displayId: input.displayId,
      orderIndex: (maxOrder._max.orderIndex ?? 0) + 1,
      category: input.category,
      severity: input.severity,
      title: input.title,
      description: input.description ?? "",
      turnsJson: JSON.stringify(input.turns),
      expectedBehavior: input.expectedBehavior,
      evidenceNote: input.evidence ?? "",
      rulesJson: JSON.stringify(input.rules ?? []),
      failureHint: input.failureHint ?? null,
      tagsCsv: (input.tags ?? []).join(","),
    },
  });

  await audit(
    "suite.case_created",
    { suiteId: suite.id, caseId: created.displayId },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk({ case: mapCaseRow(created) }, { status: 201 });
}


/* ========================================================================== */
/* from src/app/api/suites/[id]/duplicate/route.ts (/suites/[id]/duplicate) */
/* ========================================================================== */

/** Duplicate a suite (deep copy of cases; the copy is not a starter suite). */
async function suites_id_duplicate_POST(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
    include: { cases: { orderBy: { orderIndex: "asc" } } },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  const copy = await db.testSuite.create({
    data: {
      workspaceId: ctx.workspaceId,
      name: `${suite.name} (copy)`,
      description: suite.description,
      isStarter: false,
      tagsCsv: suite.tagsCsv,
      cases: {
        create: suite.cases.map((c) => ({
          displayId: c.displayId,
          orderIndex: c.orderIndex,
          category: c.category,
          severity: c.severity,
          title: c.title,
          description: c.description,
          turnsJson: c.turnsJson,
          expectedBehavior: c.expectedBehavior,
          evidenceNote: c.evidenceNote,
          rulesJson: c.rulesJson,
          failureHint: c.failureHint,
          tagsCsv: c.tagsCsv,
        })),
      },
    },
    include: { _count: { select: { cases: true } } },
  });

  await audit(
    "suite.duplicated",
    { sourceSuiteId: suite.id, newSuiteId: copy.id },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk(
    {
      suite: {
        id: copy.id,
        name: copy.name,
        description: copy.description,
        isStarter: false,
        caseCount: copy._count.cases,
        createdAt: copy.createdAt.toISOString(),
        updatedAt: copy.updatedAt.toISOString(),
      },
    },
    { status: 201 }
  );
}


/* ========================================================================== */
/* from src/app/api/suites/[id]/cases/[caseId]/route.ts (/suites/[id]/cases/[caseId]) */
/* ========================================================================== */

/** Edit a test case. */
async function suites_id_cases_caseId_PATCH(request: NextRequest, id: string, caseId: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  const existing = await db.testCase.findFirst({
    where: { id: caseId, suiteId: suite.id },
  });
  if (!existing) return jsonError("Test case not found.", 404);

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = testCaseInputSchema.partial().safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  if (input.displayId && input.displayId !== existing.displayId) {
    const dup = await db.testCase.findFirst({
      where: { suiteId: suite.id, displayId: input.displayId, NOT: { id: caseId } },
    });
    if (dup) {
      return jsonError(
        `Case id "${input.displayId}" already exists in this suite.`,
        409
      );
    }
  }

  const updated = await db.testCase.update({
    where: { id: existing.id },
    data: {
      ...(input.displayId !== undefined ? { displayId: input.displayId } : {}),
      ...(input.category !== undefined ? { category: input.category } : {}),
      ...(input.severity !== undefined ? { severity: input.severity } : {}),
      ...(input.title !== undefined ? { title: input.title } : {}),
      ...(input.description !== undefined ? { description: input.description } : {}),
      ...(input.turns !== undefined ? { turnsJson: JSON.stringify(input.turns) } : {}),
      ...(input.expectedBehavior !== undefined
        ? { expectedBehavior: input.expectedBehavior }
        : {}),
      ...(input.evidence !== undefined ? { evidenceNote: input.evidence } : {}),
      ...(input.rules !== undefined ? { rulesJson: JSON.stringify(input.rules) } : {}),
      ...(input.failureHint !== undefined ? { failureHint: input.failureHint ?? null } : {}),
      ...(input.tags !== undefined ? { tagsCsv: input.tags.join(",") } : {}),
    },
  });

  await audit(
    "suite.case_updated",
    { suiteId: suite.id, caseId: updated.displayId },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk({ case: mapCaseRow(updated) });
}

/** Remove a test case from a suite. */
async function suites_id_cases_caseId_DELETE(request: NextRequest, id: string, caseId: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const suite = await db.testSuite.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!suite) return jsonError("Test suite not found.", 404);

  const existing = await db.testCase.findFirst({
    where: { id: caseId, suiteId: suite.id },
  });
  if (!existing) return jsonError("Test case not found.", 404);

  await db.testCase.delete({ where: { id: existing.id } });
  await audit(
    "suite.case_deleted",
    { suiteId: suite.id, caseId: existing.displayId },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* from src/app/api/runs/route.ts (/runs) */
/* ========================================================================== */

const schema_runs = z.object({
  agentId: z.string().min(1),
  suiteId: z.string().min(1),
});

async function runs_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const includeSample = request.nextUrl.searchParams.get("includeSample");
  const runs = await db.testRun.findMany({
    where: {
      workspaceId: ctx.workspaceId,
      ...(includeSample === "false" ? { isSample: false } : {}),
    },
    include: {
      agent: { select: { id: true, name: true, type: true } },
      suite: { select: { id: true, name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 60,
  });

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
    select: { passThreshold: true },
  });
  const threshold = workspace?.passThreshold ?? 90;

  return jsonOk({ runs: runs.map((r) => mapRunSummary(r, threshold)) });
}

async function runs_POST(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_runs.safeParse(body);
  if (!parsed.success) return jsonError("An agent and a test suite are required.", 422);
  const { agentId, suiteId } = parsed.data;

  /* 1 — validate the agent configuration */
  const agent = await db.agent.findFirst({
    where: { id: agentId, workspaceId: ctx.workspaceId },
  });
  if (!agent) return jsonError("Agent not found.", 404);
  if (agent.status === "DISABLED") {
    return jsonError(
      "This agent connection is disabled. Enable it before running tests.",
      409
    );
  }
  if (agent.type === "CUSTOM_HTTP") {
    if (!agent.endpointUrl) {
      return jsonError(
        "This agent has no endpoint URL configured. Configure it before running tests.",
        422
      );
    }
  }

  /* 2 — validate the suite and its cases */
  const suite = await db.testSuite.findFirst({
    where: { id: suiteId, workspaceId: ctx.workspaceId },
    include: { cases: { select: { id: true } } },
  });
  if (!suite) return jsonError("Test suite not found.", 404);
  if (suite.cases.length === 0) {
    return jsonError(
      "This suite has no test cases. Add at least one case before running.",
      422
    );
  }

  /* 3 — create the run record, then execute server-side */
  const run = await db.testRun.create({
    data: {
      workspaceId: ctx.workspaceId,
      agentId: agent.id,
      suiteId: suite.id,
      agentNameSnapshot: agent.name,
      agentTypeSnapshot: agent.type,
      suiteNameSnapshot: suite.name,
      status: "QUEUED",
      totalCases: suite.cases.length,
      createdByUserId: ctx.userId,
      createdByName: ctx.name,
    },
    include: {
      agent: { select: { id: true, name: true, type: true } },
      suite: { select: { id: true, name: true } },
    },
  });

  await audit(
    "run.started",
    { runId: run.id, agentId: agent.id, suiteId: suite.id, cases: suite.cases.length },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  // Server-side execution, fire-and-forget with internal error handling.
  void executeRun(run.id);

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
    select: { passThreshold: true },
  });

  return jsonOk(
    { run: mapRunSummary(run, workspace?.passThreshold ?? 90) },
    { status: 201 }
  );
}


/* ========================================================================== */
/* from src/app/api/runs/[id]/route.ts (/runs/[id]) */
/* ========================================================================== */

async function runs_id_GET(request: NextRequest, id: string) {
  const guard = await requireReadOnlyContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const run = await db.testRun.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
    select: { id: true },
  });
  if (!run) return jsonError("Run not found.", 404);

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
    select: { passThreshold: true },
  });
  const threshold = workspace?.passThreshold ?? 90;

  // while running, return the lightweight summary + progress; the full
  // detail (with evidence) is materialized once results exist
  const full = await mapRunDetail(id, threshold);
  if (!full) return jsonError("Run not found.", 404);
  void mapRunSummary;
  return jsonOk({ run: full });
}


/* ========================================================================== */
/* from src/app/api/runs/compare/route.ts (/runs/compare) */
/* ========================================================================== */

/**
 * Compare two runs of the same suite — case-by-case status matrix with
 * regressions and improvements highlighted.
 */
async function runs_compare_GET(request: NextRequest) {
  const guard = await requireReadOnlyContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const a = request.nextUrl.searchParams.get("a");
  const b = request.nextUrl.searchParams.get("b");
  if (!a || !b) return jsonError("Provide two run ids (?a=…&b=…).", 422);
  if (a === b) return jsonError("Select two different runs to compare.", 422);

  const runs = await db.testRun.findMany({
    where: { id: { in: [a, b] }, workspaceId: ctx.workspaceId },
    include: {
      agent: { select: { id: true, name: true, type: true } },
      suite: { select: { id: true, name: true } },
      results: { orderBy: { orderIndex: "asc" }, select: { displayId: true, orderIndex: true, title: true, category: true, severity: true, status: true } },
    },
  });
  if (runs.length !== 2) return jsonError("One or both runs were not found.", 404);

  const runA = runs.find((r) => r.id === a)!;
  const runB = runs.find((r) => r.id === b)!;

  if ((runA.suiteId ?? runA.suiteNameSnapshot) !== (runB.suiteId ?? runB.suiteNameSnapshot)) {
    return jsonError(
      "These runs used different test suites, so their cases cannot be compared one-to-one.",
      422
    );
  }

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
    select: { passThreshold: true },
  });
  const threshold = workspace?.passThreshold ?? 90;

  const mapB = new Map(runB.results.map((r) => [r.displayId, r]));
  const rank: Record<ResultStatus, number> = {
    PASS: 3,
    FAIL: 1,
    INCONCLUSIVE: 2,
    ERROR: 0,
    NOT_EXECUTED: 0,
  };

  let regressions = 0;
  let improvements = 0;
  const rows = runA.results.map((ra) => {
    const rb = mapB.get(ra.displayId);
    const statusA = ra.status as ResultStatus;
    const statusB = (rb?.status ?? "NOT_EXECUTED") as ResultStatus;
    const regression = rb ? rank[statusB] < rank[statusA] && statusA === "PASS" : false;
    const improvement = rb ? rank[statusB] > rank[statusA] && statusB === "PASS" : false;
    if (regression) regressions += 1;
    if (improvement) improvements += 1;
    return {
      caseId: ra.displayId,
      order: ra.orderIndex,
      title: rb?.title ?? ra.title,
      category: (rb?.category ?? ra.category) as CompareDTO["rows"][number]["category"],
      severity: (rb?.severity ?? ra.severity) as CompareDTO["rows"][number]["severity"],
      statusA,
      statusB,
      regression,
      improvement,
    };
  });

  const compare: CompareDTO = {
    runA: mapRunSummary(runA, threshold),
    runB: mapRunSummary(runB, threshold),
    rows,
    regressions,
    improvements,
  };
  return jsonOk({ compare });
}


/* ========================================================================== */
/* from src/app/api/runs/[id]/cancel/route.ts (/runs/[id]/cancel) */
/* ========================================================================== */

async function runs_id_cancel_POST(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const run = await db.testRun.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!run) return jsonError("Run not found.", 404);

  if (run.status !== "RUNNING" && run.status !== "QUEUED") {
    return jsonError(
      `This run is already ${run.status.toLowerCase()} and cannot be cancelled.`,
      409
    );
  }
  if (run.isSample) {
    return jsonError("Simulated sample runs cannot be cancelled.", 409);
  }

  await db.testRun.update({
    where: { id: run.id },
    data: { cancelRequested: true },
  });
  await audit(
    "run.cancel_requested",
    { runId: run.id },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk({ ok: true, status: "RUNNING", note: "Cancellation requested — in-flight cases will finish; remaining cases will be marked not executed." });
}


/* ========================================================================== */
/* from src/app/api/runs/[id]/export/route.ts (/runs/[id]/export) */
/* ========================================================================== */

/**
 * Report export — JSON (full evidence) or CSV (per-case rows).
 * Generated from the SAVED results of the run, never recomputed.
 */
async function runs_id_export_GET(request: NextRequest, id: string) {
  const guard = await requireReadOnlyContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const runExists = await db.testRun.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
    select: { id: true },
  });
  if (!runExists) return jsonError("Run not found.", 404);

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
    select: { passThreshold: true, retentionDays: true },
  });
  const detail = await mapRunDetail(id, workspace?.passThreshold ?? 90);
  if (!detail) return jsonError("Run not found.", 404);

  await audit(
    "report.exported",
    { runId: id, format: request.nextUrl.searchParams.get("format") ?? "json" },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  const format = request.nextUrl.searchParams.get("format") ?? "json";

  if (format === "csv") {
    const header = [
      "case_id",
      "order",
      "category",
      "severity",
      "title",
      "status",
      "failed_rules",
      "explanation",
      "recommendation",
      "tool_events",
      "duration_ms",
    ];
    const esc = (v: string) => `"${v.replace(/"/g, '""').replace(/\r?\n/g, " ")}"`;
    const lines = [header.join(",")];
    for (const r of detail.results) {
      lines.push(
        [
          r.caseId,
          r.order,
          r.category,
          r.severity,
          r.title,
          r.status,
          r.ruleOutcomes.filter((o) => o.outcome === "FAIL").map((o) => o.label).join("; "),
          r.explanation,
          r.recommendation ?? "",
          r.toolEvents.map((e) => `${e.phase}:${e.name}(${e.status})`).join("; "),
          r.durationMs ?? "",
        ]
          .map((v) => esc(String(v)))
          .join(",")
      );
    }
    return new Response(lines.join("\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="agentclear-report-${id}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    product: "AgentClear",
    report: detail,
    methodology: {
      score:
        "Score = passed / (passed + failed + inconclusive) * 100. Execution errors and not-executed cases are excluded from the denominator but never count as passes.",
      states: {
        PASS: "All evaluation criteria passed.",
        FAIL: "At least one criterion definitively failed.",
        INCONCLUSIVE: "Evidence required for one or more criteria was not available.",
        ERROR: "Execution error (timeout, HTTP failure, etc.) — not an evaluation result.",
        NOT_EXECUTED: "The run ended before this case executed.",
      },
      toolPhases: {
        REQUESTED: "The agent indicated a tool should be used.",
        OBSERVED: "An execution trace shows the tool call occurred.",
        CONFIRMED: "A trusted tool result confirmed the outcome.",
      },
    },
  };

  return new Response(JSON.stringify(payload, null, 2), {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="agentclear-report-${id}.json"`,
      "Cache-Control": "no-store",
    },
  });
}


/* ========================================================================== */
/* from src/app/api/overview/route.ts (/overview) */
/* ========================================================================== */

async function overview_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const [workspace, agentCount, recentRuns] = await Promise.all([
    db.workspace.findUnique({
      where: { id: ctx.workspaceId },
      select: { passThreshold: true },
    }),
    db.agent.count({
      where: { workspaceId: ctx.workspaceId, status: "ACTIVE" },
    }),
    db.testRun.findMany({
      where: { workspaceId: ctx.workspaceId },
      include: {
        agent: { select: { id: true, name: true, type: true } },
        suite: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);
  const threshold = workspace?.passThreshold ?? 90;

  const summaries = recentRuns.map((r) => mapRunSummary(r, threshold));
  const realRuns = summaries.filter((r) => !r.isSample && r.status === "COMPLETED");
  const latestRun = realRuns[0] ?? null;
  const previousRun =
    realRuns.find((r) => r.suiteId === latestRun?.suiteId && r.id !== latestRun.id) ?? null;

  const scoreDelta =
    latestRun?.score != null && previousRun?.score != null
      ? Math.round((latestRun.score - previousRun.score) * 10) / 10
      : null;

  // Recent failures from the latest real completed run
  const recentFailures: OverviewDTO["recentFailures"] = [];
  const latestRealRow = recentRuns.find(
    (r) => !r.isSample && r.status === "COMPLETED"
  );
  if (latestRealRow) {
    const failing = await db.testResult.findMany({
      where: {
        runId: latestRealRow.id,
        status: { in: ["FAIL", "INCONCLUSIVE"] },
      },
      orderBy: [{ status: "desc" }, { orderIndex: "asc" }],
      take: 6,
    });
    for (const f of failing) {
      recentFailures.push({
        runId: latestRealRow.id,
        runStatus: latestRealRow.status as OverviewDTO["recentFailures"][number]["runStatus"],
        isSample: false,
        caseId: f.displayId,
        title: f.title,
        category: f.category as OverviewDTO["recentFailures"][number]["category"],
        severity: f.severity as OverviewDTO["recentFailures"][number]["severity"],
        status: f.status as ResultStatus,
        explanation: f.explanation.slice(0, 300),
        completedAt: latestRealRow.completedAt?.toISOString() ?? null,
      });
    }
  }

  const [hasSuite, hasRun] = await Promise.all([
    db.testSuite.count({ where: { workspaceId: ctx.workspaceId } }),
    db.testRun.count({
      where: { workspaceId: ctx.workspaceId, isSample: false },
    }),
  ]);

  const overview: OverviewDTO = {
    agentsConnected: agentCount,
    latestRun,
    previousRun,
    scoreDelta,
    recentRuns: summaries.slice(0, 8),
    recentFailures,
    hasAnyRealRun: realRuns.length > 0,
    onboarding: {
      hasAgent: agentCount > 0,
      hasSuite: hasSuite > 0,
      hasRun: hasRun > 0,
    },
  };

  return jsonOk(overview);
}


/* ========================================================================== */
/* from src/app/api/settings/route.ts (/settings) */
/* ========================================================================== */

const schema_settings = z.object({
  workspace: z
    .object({
      name: z.string().trim().min(1, "Workspace name is required.").max(80),
      passThreshold: z.number().int().min(1).max(100),
      retentionDays: z.number().int().min(7).max(3650),
    })
    .partial()
    .optional(),
  user: z
    .object({
      name: z.string().trim().min(1, "Name is required.").max(80),
    })
    .optional(),
});

async function settings_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
  });
  if (!workspace) return jsonError("Workspace not found.", 404);

  return jsonOk({
    settings: {
      workspace: {
        id: workspace.id,
        name: workspace.name,
        passThreshold: workspace.passThreshold,
        retentionDays: workspace.retentionDays,
      },
      user: { id: ctx.userId, email: ctx.email, name: ctx.name },
    },
  });
}

async function settings_PATCH(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_settings.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const input = parsed.data;

  if (input.workspace) {
    await db.workspace.update({
      where: { id: ctx.workspaceId },
      data: {
        ...(input.workspace.name !== undefined ? { name: input.workspace.name } : {}),
        ...(input.workspace.passThreshold !== undefined
          ? { passThreshold: input.workspace.passThreshold }
          : {}),
        ...(input.workspace.retentionDays !== undefined
          ? { retentionDays: input.workspace.retentionDays }
          : {}),
      },
    });
  }
  if (input.user) {
    await db.user.update({
      where: { id: ctx.userId },
      data: { name: input.user.name },
    });
  }

  await audit(
    "settings.updated",
    { fields: Object.keys(input) },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  const workspace = await db.workspace.findUnique({
    where: { id: ctx.workspaceId },
  });
  return jsonOk({
    settings: {
      workspace: {
        id: workspace!.id,
        name: workspace!.name,
        passThreshold: workspace!.passThreshold,
        retentionDays: workspace!.retentionDays,
      },
      user: { id: ctx.userId, email: ctx.email, name: input.user?.name ?? ctx.name },
    },
  });
}


/* ========================================================================== */
/* from src/app/api/settings/sessions/route.ts (/settings/sessions) */
/* ========================================================================== */

async function settings_sessions_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const token = await readSessionToken();
  const currentHash = token ? sha256Hex(token) : null;

  const sessions = await db.session.findMany({
    where: { userId: ctx.userId },
    orderBy: { lastSeenAt: "desc" },
    take: 30,
  });

  return jsonOk({
    sessions: sessions.map((s) => ({
      id: s.id,
      userAgent: s.userAgent,
      createdAt: s.createdAt.toISOString(),
      lastSeenAt: s.lastSeenAt.toISOString(),
      current: s.tokenHash === currentHash,
    })),
  });
}


/* ========================================================================== */
/* from src/app/api/settings/tokens/route.ts (/settings/tokens) */
/* ========================================================================== */

const createSchema_settings_tokens = z.object({
  name: z.string().trim().min(1, "Token name is required.").max(80),
});

/** List workspace API tokens (hashes only — tokens are shown once). */
async function settings_tokens_GET(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;

  const tokens = await db.apiToken.findMany({
    where: { workspaceId: guard.ctx.workspaceId },
    orderBy: { createdAt: "desc" },
  });
  return jsonOk({
    tokens: tokens.map((t) => ({
      id: t.id,
      name: t.name,
      prefix: t.prefix,
      createdAt: t.createdAt.toISOString(),
      lastUsedAt: t.lastUsedAt?.toISOString() ?? null,
    })),
  });
}

async function settings_tokens_POST(request: NextRequest) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = createSchema_settings_tokens.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }

  const count = await db.apiToken.count({
    where: { workspaceId: ctx.workspaceId },
  });
  if (count >= 20) {
    return jsonError("This workspace already has 20 tokens. Revoke one first.", 409);
  }

  const token = `ap_${randomToken(24)}`;
  const record = await db.apiToken.create({
    data: {
      workspaceId: ctx.workspaceId,
      name: parsed.data.name,
      tokenHash: sha256Hex(token),
      prefix: token.slice(0, 11),
    },
  });

  await audit(
    "token.created",
    { tokenId: record.id, name: record.name },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );

  return jsonOk(
    {
      token: {
        id: record.id,
        name: record.name,
        prefix: record.prefix,
        createdAt: record.createdAt.toISOString(),
        lastUsedAt: null,
        token, // shown exactly once
      },
    },
    { status: 201 }
  );
}


/* ========================================================================== */
/* from src/app/api/settings/sessions/[id]/route.ts (/settings/sessions/[id]) */
/* ========================================================================== */

/** Revoke a session (sign out that device). */
async function settings_sessions_id_DELETE(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const auth = await getAuth();
  if (!auth) return jsonError("Authentication required.", 401);

  const session = await db.session.findUnique({ where: { id } });
  if (!session || session.userId !== auth.userId) {
    return jsonError("Session not found.", 404);
  }
  await db.session.delete({ where: { id } });
  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* from src/app/api/settings/tokens/[id]/route.ts (/settings/tokens/[id]) */
/* ========================================================================== */

async function settings_tokens_id_DELETE(request: NextRequest, id: string) {
  const guard = await requireWorkspaceContext(request);
  if ("response" in guard) return guard.response;
  const ctx = guard.ctx;

  const token = await db.apiToken.findFirst({
    where: { id, workspaceId: ctx.workspaceId },
  });
  if (!token) return jsonError("Token not found.", 404);

  await db.apiToken.delete({ where: { id: token.id } });
  await audit(
    "token.revoked",
    { tokenId: token.id, name: token.name },
    { workspaceId: ctx.workspaceId, userId: ctx.userId }
  );
  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* from src/app/api/account/route.ts (/account) */
/* ========================================================================== */

const schema_account = z.object({
  scope: z.enum(["account", "workspace"]),
  confirm: z.literal("DELETE", {
    message: 'Type DELETE to confirm — this action cannot be undone.',
  }),
});

/**
 * Destructive deletion:
 *  - scope=workspace: deletes the active workspace and everything in it
 *  - scope=account: deletes the user, all their workspaces, and all sessions
 */
async function account_DELETE(request: NextRequest) {
  const guard = await requireSession();
  if ("response" in guard) return guard.response;
  const auth = guard.auth;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_account.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }
  const { scope } = parsed.data;

  if (scope === "workspace") {
    // resolve the workspace from the header (must belong to the user)
    const headerId = request.headers.get("X-Workspace-Id");
    const memberships = await db.membership.findMany({
      where: { userId: auth.userId },
    });
    const target =
      headerId != null
        ? memberships.find((m) => m.workspaceId === headerId)
        : memberships[0];
    if (!target) return jsonError("Workspace not found for this account.", 404);

    // safety: refuse while runs are executing
    const activeRuns = await db.testRun.count({
      where: { workspaceId: target.workspaceId, status: { in: ["QUEUED", "RUNNING"] } },
    });
    if (activeRuns > 0) {
      return jsonError(
        "This workspace has runs in progress. Cancel them before deleting.",
        409
      );
    }

    await db.workspace.delete({ where: { id: target.workspaceId } });
    await audit(
      "workspace.deleted",
      { workspaceId: target.workspaceId },
      { userId: auth.userId }
    );

    const remaining = await db.membership.count({ where: { userId: auth.userId } });
    if (remaining === 0) {
      // last workspace gone → delete the account too
      await db.user.delete({ where: { id: auth.userId } });
      await audit("account.deleted", { cascade: "last-workspace" }, { userId: null });
      const res = jsonOk({ ok: true, accountDeleted: true });
      res.cookies.set("ap_session", "", { path: "/", expires: new Date(0) });
      return res;
    }
    return jsonOk({ ok: true, accountDeleted: false });
  }

  // scope === account
  const activeRuns = await db.testRun.count({
    where: { workspace: { memberships: { some: { userId: auth.userId } } }, status: { in: ["QUEUED", "RUNNING"] } },
  });
  if (activeRuns > 0) {
    return jsonError(
      "You have runs in progress. Cancel them before deleting your account.",
      409
    );
  }

  await audit("account.deleted", {}, { userId: null });
  await db.user.delete({ where: { id: auth.userId } }); // cascades workspaces, sessions, etc.
  void destroyAllSessions;
  const res = jsonOk({ ok: true, accountDeleted: true });
  res.cookies.set("ap_session", "", { path: "/", expires: new Date(0) });
  return res;
}


/* ========================================================================== */
/* from src/app/api/contact/route.ts (/contact) */
/* ========================================================================== */

const schema_contact = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address."),
  message: z.string().trim().min(10, "Message must be at least 10 characters.").max(5000),
});

/**
 * Public contact form — stores messages in this deployment's database only.
 * No email is sent (disclosed in the UI and docs).
 */
async function contact_POST(request: NextRequest) {
  const ip = clientIp(request);
  const rl = rateLimit(`contact:${ip}`, 5, 60 * 60 * 1000);
  if (!rl.ok) {
    return jsonError("Too many messages sent. Try again later.", 429);
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return jsonError("Invalid request body.");
  }
  const parsed = schema_contact.safeParse(body);
  if (!parsed.success) {
    return jsonError(parsed.error.issues[0]?.message ?? "Invalid input.", 422);
  }

  await db.contactMessage.create({
    data: { email: parsed.data.email, message: parsed.data.message },
  });

  return jsonOk({ ok: true });
}


/* ========================================================================== */
/* Dispatcher — maps (method, path segments) onto the handlers above.          */
/* ========================================================================== */

type ApiRouteCtx = { params: Promise<{ path: string[] }> };

async function dispatch(
  method: "GET" | "POST" | "PATCH" | "PUT" | "DELETE",
  request: NextRequest,
  segs: string[]
): Promise<Response> {
  const key = segs.join("/");
  const n = segs.length;
  switch (key) {
    case "auth/login":
      if (method === "POST") return auth_login_POST(request);
      break;
    case "auth/logout":
      if (method === "POST") return auth_logout_POST(request);
      break;
    case "auth/session":
      if (method === "GET") return auth_session_GET(request);
      break;
    case "auth/signup":
      if (method === "POST") return auth_signup_POST(request);
      break;
    case "agents":
      if (method === "GET") return agents_GET(request);
      if (method === "POST") return agents_POST(request);
      break;
    case "suites":
      if (method === "GET") return suites_GET(request);
      if (method === "POST") return suites_POST(request);
      break;
    case "runs":
      if (method === "GET") return runs_GET(request);
      if (method === "POST") return runs_POST(request);
      break;
    case "runs/compare":
      if (method === "GET") return runs_compare_GET(request);
      break;
    case "overview":
      if (method === "GET") return overview_GET(request);
      break;
    case "settings":
      if (method === "GET") return settings_GET(request);
      if (method === "PATCH") return settings_PATCH(request);
      break;
    case "settings/sessions":
      if (method === "GET") return settings_sessions_GET(request);
      break;
    case "settings/tokens":
      if (method === "GET") return settings_tokens_GET(request);
      if (method === "POST") return settings_tokens_POST(request);
      break;
    case "account":
      if (method === "DELETE") return account_DELETE(request);
      break;
    case "contact":
      if (method === "POST") return contact_POST(request);
      break;
  }
  // dynamic segments ([id], [caseId]) resolved positionally
  if (n === 2) {
    const [a, id] = segs;
    if (a === "agents") {
      if (method === "GET") return agents_id_GET(request, id);
      if (method === "PATCH") return agents_id_PATCH(request, id);
      if (method === "DELETE") return agents_id_DELETE(request, id);
    }
    if (a === "runs") {
      if (method === "GET") return runs_id_GET(request, id);
    }
    if (a === "suites") {
      if (method === "GET") return suites_id_GET(request, id);
      if (method === "PATCH") return suites_id_PATCH(request, id);
      if (method === "DELETE") return suites_id_DELETE(request, id);
    }
  }
  if (n === 3) {
    const [a, id, tail] = segs;
    if (a === "agents" && tail === "test") {
      if (method === "POST") return agents_id_test_POST(request, id);
    }
    if (a === "runs" && (tail === "cancel" || tail === "export")) {
      if (method === "POST" && tail === "cancel") return runs_id_cancel_POST(request, id);
      if (method === "GET" && tail === "export") return runs_id_export_GET(request, id);
    }
    if (a === "suites" && (tail === "duplicate" || tail === "cases")) {
      if (method === "POST" && tail === "duplicate") return suites_id_duplicate_POST(request, id);
      if (method === "POST" && tail === "cases") return suites_id_cases_POST(request, id);
    }
    if (a === "settings" && segs[1] === "sessions") {
      if (method === "DELETE") return settings_sessions_id_DELETE(request, tail);
    }
    if (a === "settings" && segs[1] === "tokens") {
      if (method === "DELETE") return settings_tokens_id_DELETE(request, tail);
    }
  }
  if (n === 4) {
    const [a, id, mid, caseId] = segs;
    if (a === "suites" && mid === "cases") {
      if (method === "PATCH") return suites_id_cases_caseId_PATCH(request, id, caseId);
      if (method === "DELETE") return suites_id_cases_caseId_DELETE(request, id, caseId);
    }
  }
  return jsonError(`No API route for ${method} /api/${key}.`, 404);
}

export async function GET(request: NextRequest, ctx: ApiRouteCtx) {
  return dispatch("GET", request, (await ctx.params).path);
}

export async function POST(request: NextRequest, ctx: ApiRouteCtx) {
  return dispatch("POST", request, (await ctx.params).path);
}

export async function PATCH(request: NextRequest, ctx: ApiRouteCtx) {
  return dispatch("PATCH", request, (await ctx.params).path);
}

export async function PUT(request: NextRequest, ctx: ApiRouteCtx) {
  return dispatch("PUT", request, (await ctx.params).path);
}

export async function DELETE(request: NextRequest, ctx: ApiRouteCtx) {
  return dispatch("DELETE", request, (await ctx.params).path);
}
