import { PrismaClient } from "@prisma/client";
import { cookies, headers } from "next/headers";
import { NextResponse } from "next/server";
import crypto from "node:crypto";
import dns from "node:dns/promises";
import net from "node:net";
import { URL } from "node:url";
import { z } from "zod";

import { DEFAULT_BODY_TEMPLATE } from "@/lib/engine";
import { buildSampleRunDetail } from "@/lib/starter-suite";
import { STARTER_SUITE, STARTER_SUITE_DESCRIPTION, STARTER_SUITE_NAME } from "@/lib/starter-suite";
import { AgentDTO, CaseResultDTO, RunDetailDTO, RunSummaryDTO, SuiteDetail, SuiteSummary, TestCaseData, ToolEventDTO, TurnEvidenceDTO } from "@/lib/types";



/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/db.ts */
/* ========================================================================== */

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.PRISMA_LOG_QUERY === '1' ? ['query'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/crypto.ts */
/* ========================================================================== */

/**
 * Secret encryption — AES-256-GCM.
 *
 * The key comes from the ENCRYPTION_KEY environment variable (base64 or hex,
 * 32 bytes). If it is missing (e.g. local development), a deterministic dev
 * key is derived and a warning is logged — this is disclosed in the docs;
 * production deployments MUST set ENCRYPTION_KEY.
 */

let cachedKey: Buffer | null = null;
let warned = false;

function getKey(): Buffer {
  if (cachedKey) return cachedKey;
  const raw = process.env.ENCRYPTION_KEY;
  if (raw && raw.length > 0) {
    let key: Buffer | null = null;
    try {
      key = Buffer.from(raw, "base64");
    } catch {
      key = null;
    }
    if (!key || key.length !== 32) {
      try {
        key = Buffer.from(raw, "hex");
      } catch {
        key = null;
      }
    }
    if (key && key.length === 32) {
      cachedKey = key;
      return key;
    }
    console.warn(
      "[agentclear] ENCRYPTION_KEY is set but is not a valid 32-byte base64/hex value — falling back to a derived dev key. Secrets stored now will not decrypt after the key is fixed."
    );
  }
  if (!warned) {
    warned = true;
    console.warn(
      "[agentclear] ENCRYPTION_KEY is not configured. Using a derived development key. Set ENCRYPTION_KEY (32 bytes, base64) in production."
    );
  }
  cachedKey = crypto
    .createHash("sha256")
    .update(`agentclear-dev-key:${process.env.DATABASE_URL ?? "local"}`)
    .digest();
  return cachedKey;
}

/** Encrypt a UTF-8 secret → base64(iv ‖ tag ‖ ciphertext). */
export function encryptSecret(plaintext: string): string {
  const key = getKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, ct]).toString("base64");
}

/** Decrypt a value produced by encryptSecret. Returns null if it fails. */
export function decryptSecret(payload: string): string | null {
  try {
    const key = getKey();
    const buf = Buffer.from(payload, "base64");
    const iv = buf.subarray(0, 12);
    const tag = buf.subarray(12, 28);
    const ct = buf.subarray(28);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString("utf8");
  } catch {
    return null;
  }
}

/** scrypt password hashing (salted, timing-safe comparison). */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, saltHex, hashHex] = stored.split("$");
    if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
    const salt = Buffer.from(saltHex, "hex");
    const expected = Buffer.from(hashHex, "hex");
    const actual = crypto.scryptSync(password, salt, expected.length);
    return crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString("base64url");
}

export function sha256Hex(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex");
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/rate-limit.ts */
/* ========================================================================== */

/**
 * Simple in-memory rate limiter (per key). Adequate for a single-node
 * deployment; documented as such. Not a distributed limiter.
 */

const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number
): { ok: boolean; retryAfterSec: number } {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, retryAfterSec: 0 };
  }
  if (bucket.count >= limit) {
    return {
      ok: false,
      retryAfterSec: Math.ceil((bucket.resetAt - now) / 1000),
    };
  }
  bucket.count += 1;
  return { ok: true, retryAfterSec: 0 };
}

/** Best-effort client IP for rate limiting (behind the gateway). */
export function clientIp(request: Request): string {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "unknown"
  );
}

// Periodic cleanup to avoid unbounded growth
if (typeof setInterval !== "undefined") {
  const timer = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of buckets) {
      if (v.resetAt < now) buckets.delete(k);
    }
  }, 60_000);
  if (typeof timer === "object" && "unref" in timer) timer.unref();
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/audit.ts */
/* ========================================================================== */

/** Append-only audit log for security-relevant actions. */
export async function audit(
  action: string,
  detail: Record<string, unknown> = {},
  ctx?: { workspaceId?: string | null; userId?: string | null }
) {
  try {
    await db.auditEvent.create({
      data: {
        action,
        workspaceId: ctx?.workspaceId ?? null,
        userId: ctx?.userId ?? null,
        detailJson: JSON.stringify(detail).slice(0, 4000),
      },
    });
  } catch (e) {
    // Audit failures must never break the request path.
    console.error("[agentclear] audit write failed", e);
  }
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/auth.ts */
/* ========================================================================== */

/**
 * Session authentication — DB-backed opaque tokens in httpOnly cookies.
 * No credentials ever reach client-side JavaScript.
 */

export const SESSION_COOKIE = "ap_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14; // 14 days

export interface AuthContext {
  userId: string;
  sessionId: string;
  email: string;
  name: string;
}

export async function createSession(
  userId: string,
  userAgent: string | null
): Promise<{ token: string; expiresAt: Date }> {
  const token = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.session.create({
    data: {
      tokenHash: sha256Hex(token),
      userId,
      expiresAt,
      userAgent: userAgent?.slice(0, 250) ?? null,
    },
  });
  return { token, expiresAt };
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true as const,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  };
}

export async function readSessionToken(): Promise<string | null> {
  const store = await cookies();
  return store.get(SESSION_COOKIE)?.value ?? null;
}

/** Resolve the current auth context from the session cookie. */
export async function getAuth(): Promise<AuthContext | null> {
  const token = await readSessionToken();
  if (!token) return null;
  const session = await db.session.findUnique({
    where: { tokenHash: sha256Hex(token) },
    include: { user: { select: { id: true, email: true, name: true } } },
  });
  if (!session) return null;
  if (session.expiresAt < new Date()) {
    await db.session.delete({ where: { id: session.id } }).catch(() => {});
    return null;
  }
  // touch last seen (best effort, throttled by update absence)
  await db.session
    .update({
      where: { id: session.id },
      data: { lastSeenAt: new Date() },
    })
    .catch(() => {});
  return {
    userId: session.user.id,
    sessionId: session.id,
    email: session.user.email,
    name: session.user.name,
  };
}

export async function destroyCurrentSession(): Promise<void> {
  const token = await readSessionToken();
  if (!token) return;
  await db.session
    .delete({ where: { tokenHash: sha256Hex(token) } })
    .catch(() => {});
}

export async function destroyAllSessions(userId: string): Promise<void> {
  await db.session.deleteMany({ where: { userId } });
}

/* ------------------------------------------------------------------ */
/* Workspace scoping                                                    */
/* ------------------------------------------------------------------ */

export interface WorkspaceContext extends AuthContext {
  workspaceId: string;
  workspaceName: string;
  role: string;
}

/**
 * Resolve the active workspace for a request.
 * Reads X-Workspace-Id header; verifies membership; falls back to the
 * user's first workspace. Cross-workspace IDs are rejected here — every
 * downstream query is then scoped to workspaceId.
 */
export async function resolveWorkspace(
  auth: AuthContext,
  request: Request
): Promise<WorkspaceContext | null> {
  const headerId = request.headers.get("X-Workspace-Id");
  const memberships = await db.membership.findMany({
    where: { userId: auth.userId },
    include: { workspace: { select: { id: true, name: true } } },
    orderBy: { createdAt: "asc" },
  });
  if (memberships.length === 0) return null;
  let membership =
    headerId != null
      ? memberships.find((m) => m.workspaceId === headerId) ?? null
      : null;
  if (!membership && !headerId) membership = memberships[0];
  if (!membership) return null;
  return {
    ...auth,
    workspaceId: membership.workspaceId,
    workspaceName: membership.workspace.name,
    role: membership.role,
  };
}



/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/api.ts */
/* ========================================================================== */

/**
 * API route helpers: auth guards, workspace scoping, JSON responses,
 * and read-only API-token authentication.
 */

export function jsonOk<T>(data: T, init?: ResponseInit) {
  return NextResponse.json(data, {
    ...init,
    headers: {
      "Cache-Control": "no-store",
      ...(init?.headers ?? {}),
    },
  });
}

export function jsonError(message: string, status = 400, code?: string) {
  return NextResponse.json(
    { error: message, ...(code ? { code } : {}) },
    { status, headers: { "Cache-Control": "no-store" } }
  );
}

export async function readJsonBody<T>(request: Request): Promise<T | null> {
  try {
    const text = await request.text();
    if (!text) return null;
    if (text.length > 256 * 1024) throw new Error("too large");
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

/** Require an authenticated session. Returns null + 401 response. */
export async function requireSession(): Promise<
  { auth: NonNullable<Awaited<ReturnType<typeof getAuth>>> } | { response: NextResponse }
> {
  const auth = await getAuth();
  if (!auth) {
    return { response: jsonError("Authentication required.", 401, "UNAUTHENTICATED") };
  }
  return { auth };
}

/** Require an authenticated session with a valid workspace context. */
export async function requireWorkspaceContext(
  request: Request
): Promise<{ ctx: WorkspaceContext } | { response: NextResponse }> {
  const result = await requireSession();
  if ("response" in result) return result;
  const ctx = await resolveWorkspace(result.auth, request);
  if (!ctx) {
    return {
      response: jsonError(
        "Workspace not found for this account, or the requested workspace is not accessible.",
        403,
        "WORKSPACE_FORBIDDEN"
      ),
    };
  }
  return { ctx };
}

/* ------------------------------------------------------------------ */
/* Read-only API token auth (for programmatic report access)           */
/* ------------------------------------------------------------------ */

export interface TokenContext {
  workspaceId: string;
  tokenId: string;
}

export async function resolveApiToken(
  request: Request
): Promise<TokenContext | null> {
  const authz = request.headers.get("authorization");
  if (!authz?.startsWith("Bearer ")) return null;
  const token = authz.slice(7).trim();
  if (!token) return null;
  const record = await db.apiToken.findUnique({
    where: { tokenHash: sha256Hex(token) },
  });
  if (!record) return null;
  // best-effort usage timestamp
  db.apiToken
    .update({ where: { id: record.id }, data: { lastUsedAt: new Date() } })
    .catch(() => {});
  return { workspaceId: record.workspaceId, tokenId: record.id };
}

/** Auth for read-only endpoints: session OR api token. */
export async function requireReadOnlyContext(
  request: Request
): Promise<{ ctx: WorkspaceContext; viaToken: boolean } | { response: NextResponse }> {
  if (request.method !== "GET" && request.method !== "HEAD") {
    return {
      response: jsonError(
        "API tokens are read-only. Sign in to the workspace for write operations.",
        405,
        "TOKEN_READ_ONLY"
      ),
    };
  }
  const token = await resolveApiToken(request);
  if (token) {
    const workspace = await db.workspace.findUnique({
      where: { id: token.workspaceId },
      select: { id: true, name: true },
    });
    if (!workspace) {
      return { response: jsonError("Workspace for this token no longer exists.", 403) };
    }
    // synthesize a context
    return {
      ctx: {
        userId: `token:${token.tokenId}`,
        sessionId: "",
        email: "",
        name: "API token",
        workspaceId: workspace.id,
        workspaceName: workspace.name,
        role: "MEMBER",
      },
      viaToken: true,
    };
  }
  const result = await requireWorkspaceContext(request);
  if ("response" in result) return result;
  return { ctx: result.ctx, viaToken: false };
}

export async function requestUserAgent(): Promise<string | null> {
  const h = await headers();
  return h.get("user-agent");
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/ssrf.ts */
/* ========================================================================== */

/**
 * SSRF guard for user-configured agent endpoints.
 *
 * User-supplied endpoints are untrusted. Before any outbound request:
 *  - only http/https schemes are allowed
 *  - URLs with embedded credentials are rejected
 *  - the hostname is resolved and every address is checked against
 *    private / reserved / link-local / cloud-metadata ranges
 *  - redirects are refused at fetch time (revalidation-by-refusal)
 *  - timeouts and response-size caps are enforced by the caller
 *
 * Known residual limitation (documented in /docs): a TOCTOU DNS-rebinding
 * window between validation and the actual request exists; we mitigate by
 * validating immediately before each request.
 */

const BLOCKED_HOSTNAMES = new Set([
  "metadata.google.internal",
  "metadata.goog",
]);

function ipToLong(ip: string): number | null {
  const parts = ip.split(".");
  if (parts.length !== 4) return null;
  let n = 0;
  for (const p of parts) {
    const v = Number(p);
    if (!Number.isInteger(v) || v < 0 || v > 255) return null;
    n = n * 256 + v;
  }
  return n;
}

const blockedV4: [string, string][] = [
  ["0.0.0.0", "0.255.255.255"], // "this" network
  ["10.0.0.0", "10.255.255.255"], // private
  ["100.64.0.0", "100.127.255.255"], // CGNAT
  ["127.0.0.0", "127.255.255.255"], // loopback
  ["169.254.0.0", "169.254.255.255"], // link-local + cloud metadata (169.254.169.254)
  ["172.16.0.0", "172.31.255.255"], // private
  ["192.0.0.0", "192.0.0.255"], // IETF protocol assignments
  ["192.168.0.0", "192.168.255.255"], // private
  ["198.18.0.0", "198.19.255.255"], // benchmarking
  ["224.0.0.0", "239.255.255.255"], // multicast
  ["240.0.0.0", "255.255.255.255"], // reserved
];

function isBlockedIp(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const n = ipToLong(ip);
    if (n === null) return true;
    return blockedV4.some(([start, end]) => {
      const s = ipToLong(start)!;
      const e = ipToLong(end)!;
      return n >= s && n <= e;
    });
  }
  if (net.isIPv6(ip)) {
    const norm = ip.toLowerCase();
    if (norm === "::1" || norm === "::") return true;
    if (norm.startsWith("fc") || norm.startsWith("fd")) return true; // fc00::/7 unique-local
    if (norm.startsWith("fe8") || norm.startsWith("fe9") || norm.startsWith("fea") || norm.startsWith("feb"))
      return true; // fe80::/10 link-local
    if (norm.startsWith("ff")) return true; // multicast
    if (norm.startsWith("2001:db8")) return true; // documentation
    // IPv4-mapped addresses
    const mapped = norm.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isBlockedIp(mapped[1]);
    return false;
  }
  return true; // unknown family → block
}

export class SsrfError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SsrfError";
  }
}

export async function assertSafeHttpUrl(raw: string): Promise<URL> {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    throw new SsrfError("The endpoint URL is not valid.");
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new SsrfError(
      "Only http:// and https:// endpoints are allowed."
    );
  }
  if (url.username || url.password) {
    throw new SsrfError("URLs with embedded credentials are not allowed.");
  }
  const host = url.hostname.toLowerCase().replace(/\.$/, "");
  if (BLOCKED_HOSTNAMES.has(host)) {
    throw new SsrfError("This hostname is blocked by the SSRF guard.");
  }
  if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host.endsWith(".internal")) {
    throw new SsrfError(
      "Local and internal hostnames are blocked. Configure a public endpoint."
    );
  }
  // Literal IP in the URL
  if (net.isIP(host)) {
    if (isBlockedIp(host)) {
      throw new SsrfError(
        "Requests to private, loopback, link-local and metadata addresses are blocked."
      );
    }
    return url;
  }
  // Resolve DNS and check all resulting addresses
  let records: { address: string }[];
  try {
    records = await dns.lookup(host, { all: true });
  } catch {
    throw new SsrfError(`Could not resolve hostname "${host}".`);
  }
  if (records.length === 0) {
    throw new SsrfError(`Could not resolve hostname "${host}".`);
  }
  for (const r of records) {
    if (isBlockedIp(r.address)) {
      throw new SsrfError(
        `Hostname "${host}" resolves to a blocked address (${r.address}). Requests to private, loopback, link-local and metadata addresses are blocked.`
      );
    }
  }
  return url;
}

export interface GuardedFetchOptions {
  method: string;
  headers: Record<string, string>;
  body?: string;
  timeoutMs: number;
  maxResponseBytes?: number;
}

export interface GuardedFetchResult {
  ok: boolean;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  bodyText: string;
  truncated: boolean;
  durationMs: number;
}

/**
 * Fetch with SSRF validation, no redirects, timeout, and response size cap.
 * Validate the URL immediately before the request.
 */
export async function guardedFetch(
  rawUrl: string,
  opts: GuardedFetchOptions
): Promise<GuardedFetchResult> {
  const url = await assertSafeHttpUrl(rawUrl);
  const maxBytes = opts.maxResponseBytes ?? 1024 * 1024; // 1 MiB
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs);
  const started = Date.now();

  try {
    const res = await fetch(url, {
      method: opts.method,
      headers: opts.headers,
      body: opts.body,
      redirect: "error", // never follow redirects — prevents SSRF via redirect
      signal: controller.signal,
      cache: "no-store",
    });

    // read with a size cap
    let bodyText = "";
    let truncated = false;
    const reader = res.body?.getReader();
    if (reader) {
      const decoder = new TextDecoder();
      let received = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        received += value.byteLength;
        if (received > maxBytes) {
          truncated = true;
          await reader.cancel().catch(() => {});
          bodyText += decoder.decode(value.subarray(0, maxBytes - (received - value.byteLength)));
          break;
        }
        bodyText += decoder.decode(value, { stream: true });
      }
      bodyText += decoder.decode();
    } else {
      bodyText = await res.text();
      if (bodyText.length > maxBytes) {
        bodyText = bodyText.slice(0, maxBytes);
        truncated = true;
      }
    }

    const headerMap: Record<string, string> = {};
    res.headers.forEach((v, k) => {
      headerMap[k.toLowerCase()] = v;
    });

    return {
      ok: res.ok,
      status: res.status,
      statusText: res.statusText,
      headers: headerMap,
      bodyText,
      truncated,
      durationMs: Date.now() - started,
    };
  } catch (e) {
    const err = e as Error;
    if (err.name === "AbortError") {
      throw new SsrfError(
        `Request timed out after ${opts.timeoutMs}ms.`
      );
    }
    if (err.message?.includes("redirect")) {
      throw new SsrfError(
        "The endpoint attempted to redirect the request. Redirects are blocked by the SSRF guard."
      );
    }
    throw new SsrfError(
      err.message?.slice(0, 200) || "The request could not be completed."
    );
  } finally {
    clearTimeout(timer);
  }
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/runs-dto.ts */
/* ========================================================================== */

/**
 * DTO mappers — run rows → API shapes. Scores come straight from the
 * saved results; nothing here recomputes or invents values.
 */

type RunRow = {
  id: string;
  status: string;
  isSample: boolean;
  totalCases: number;
  passed: number;
  failed: number;
  inconclusive: number;
  errored: number;
  notExecuted: number;
  score: number | null;
  categoriesJson: string;
  startedAt: Date | null;
  completedAt: Date | null;
  durationMs: number | null;
  createdByUserId: string;
  createdByName: string;
  agentNameSnapshot: string;
  agentTypeSnapshot: string;
  suiteNameSnapshot: string;
  agent: { id: string; name: string; type: string } | null;
  suite: { id: string; name: string } | null;
};

export function mapRunSummary(run: RunRow, threshold: number): RunSummaryDTO {
  let categories: RunSummaryDTO["categories"];
  try {
    categories = JSON.parse(run.categoriesJson || "{}");
  } catch {
    categories = {
      CORRECTNESS: { total: 0, passed: 0, failed: 0, inconclusive: 0, errored: 0, notExecuted: 0 },
      TOOL_USAGE: { total: 0, passed: 0, failed: 0, inconclusive: 0, errored: 0, notExecuted: 0 },
      SAFETY: { total: 0, passed: 0, failed: 0, inconclusive: 0, errored: 0, notExecuted: 0 },
    };
  }
  const evaluated = run.passed + run.failed + run.inconclusive;
  return {
    id: run.id,
    agentId: run.agent?.id ?? "deleted",
    agentName: run.agent?.name ?? run.agentNameSnapshot ?? "Deleted agent",
    agentType: (run.agent?.type ?? run.agentTypeSnapshot) as RunSummaryDTO["agentType"],
    suiteId: run.suite?.id ?? "deleted",
    suiteName: run.suite?.name ?? run.suiteNameSnapshot ?? "Deleted suite",
    status: run.status as RunSummaryDTO["status"],
    isSample: run.isSample,
    total: run.totalCases,
    executed: evaluated,
    passed: run.passed,
    failed: run.failed,
    inconclusive: run.inconclusive,
    errored: run.errored,
    notExecuted: run.notExecuted,
    score: run.score,
    threshold,
    startedAt: (run.startedAt ?? new Date(0)).toISOString(),
    completedAt: run.completedAt?.toISOString() ?? null,
    durationMs: run.durationMs,
    createdBy: run.createdByName || run.createdByUserId,
    categories,
  };
}

export async function mapRunDetail(
  runId: string,
  threshold: number
): Promise<RunDetailDTO | null> {
  const run = await db.testRun.findUnique({
    where: { id: runId },
    include: {
      agent: { select: { id: true, name: true, type: true } },
      suite: { select: { id: true, name: true } },
      results: {
        orderBy: { orderIndex: "asc" },
        include: { toolEvents: { orderBy: { orderIndex: "asc" } } },
      },
    },
  });
  if (!run) return null;

  const results: CaseResultDTO[] = run.results.map((r) => {
    let turns: TurnEvidenceDTO[] = [];
    try {
      turns = JSON.parse(r.turnsEvidenceJson || "[]");
    } catch {
      turns = [];
    }
    let ruleOutcomes: CaseResultDTO["ruleOutcomes"] = [];
    try {
      ruleOutcomes = JSON.parse(r.ruleOutcomesJson || "[]");
    } catch {
      ruleOutcomes = [];
    }
    const toolEvents: ToolEventDTO[] = r.toolEvents.map((e) => {
      const args = e.argumentsJson ? safeParse(e.argumentsJson) : undefined;
      return {
        phase: e.phase as ToolEventDTO["phase"],
        name: e.name,
        arguments:
          args && typeof args === "object" && !Array.isArray(args)
            ? (args as Record<string, unknown>)
            : undefined,
        status: e.status as ToolEventDTO["status"],
        result: e.resultJson ? safeParse(e.resultJson) : undefined,
        timestamp: e.timestamp?.toISOString(),
        turn: e.turnIndex ?? undefined,
      };
    });
    return {
      caseId: r.displayId,
      order: r.orderIndex,
      title: r.title,
      category: r.category as CaseResultDTO["category"],
      severity: r.severity as CaseResultDTO["severity"],
      status: r.status as CaseResultDTO["status"],
      explanation: r.explanation,
      recommendation: r.recommendation ?? undefined,
      observedReply: r.observedReply ?? undefined,
      expectedBehavior: r.expectedBehavior,
      evidence: r.evidenceNote,
      failureHint: r.failureHint ?? undefined,
      turns,
      toolEvents,
      ruleOutcomes,
      durationMs: r.durationMs ?? undefined,
    };
  });

  const summary = mapRunSummary(run, threshold);
  return {
    ...summary,
    results,
    limitations: [
      "Score = passed ÷ (pass + fail + inconclusive). Execution errors and not-executed cases are excluded from the denominator but never count as passes.",
      run.isSample
        ? "This is SIMULATED SAMPLE data — no agent was executed and no HTTP requests were sent."
        : "Tool verification depends on the agent returning a tool-call trace. Missing traces are reported as inconclusive, never as passes.",
      `The ${threshold}% pass threshold is a workspace configuration and does not certify production safety.`,
    ],
  };
}

function safeParse(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return s;
  }
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/agents-shared.ts */
/* ========================================================================== */

/** Shared agent input validation + DTO mapping (used by multiple routes). */

export const agentInputSchema = z.object({
  name: z.string().trim().min(1, "Agent name is required.").max(100),
  description: z.string().trim().max(600).optional().default(""),
  type: z.enum(["DEMO_SANDBOX", "CUSTOM_HTTP"]).default("CUSTOM_HTTP"),
  endpointUrl: z.string().trim().max(2000).optional().nullable(),
  method: z.enum(["POST", "PUT", "PATCH"]).default("POST"),
  headers: z
    .record(z.string().max(100), z.string().max(2000))
    .optional()
    .default({}),
  bodyTemplate: z.string().max(8000).optional(),
  responseField: z
    .string()
    .trim()
    .max(120)
    .regex(/^[A-Za-z0-9_.[\]-]*$/, "Response field must be a dot path like data.reply")
    .optional()
    .default("reply"),
  toolCallsField: z
    .string()
    .trim()
    .max(120)
    .regex(/^[A-Za-z0-9_.[\]-]*$/, "Tool-calls field must be a dot path like events.tool_calls")
    .optional()
    .default("tool_calls"),
  authType: z.enum(["NONE", "BEARER", "HEADER", "BASIC"]).default("NONE"),
  authHeaderName: z.string().trim().max(100).optional().nullable(),
  secret: z.string().max(4000).optional().nullable(),
  timeoutMs: z.number().int().min(1000).max(120000).optional().default(15000),
  expectedContentType: z.enum(["JSON", "TEXT"]).default("JSON"),
  status: z.enum(["ACTIVE", "DISABLED"]).optional().default("ACTIVE"),
});

export type AgentRowLike = {
  id: string;
  name: string;
  description: string;
  category: string;
  type: string;
  endpointUrl: string | null;
  method: string;
  headersJson: string;
  bodyTemplate: string;
  responseField: string;
  toolCallsField: string;
  authType: string;
  authHeaderName: string | null;
  secretCiphertext: string | null;
  timeoutMs: number;
  expectedContentType: string;
  status: string;
  connectionStatus: string;
  lastTestedAt: Date | null;
  lastTestResultJson: string | null;
  createdAt: Date;
  updatedAt: Date;
};

export function mapAgentRow(row: AgentRowLike): AgentDTO {
  let headers: Record<string, string> = {};
  try {
    headers = JSON.parse(row.headersJson || "{}");
  } catch {
    headers = {};
  }
  let lastTestResult: AgentDTO["lastTestResult"] = null;
  try {
    lastTestResult = row.lastTestResultJson ? JSON.parse(row.lastTestResultJson) : null;
  } catch {
    lastTestResult = null;
  }
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    category: "CUSTOMER_SUPPORT",
    type: row.type as AgentDTO["type"],
    endpointUrl: row.endpointUrl,
    method: row.method,
    headers,
    bodyTemplate: row.bodyTemplate,
    responseField: row.responseField,
    toolCallsField: row.toolCallsField,
    authType: row.authType as AgentDTO["authType"],
    authHeaderName: row.authHeaderName,
    hasSecret: Boolean(row.secretCiphertext),
    timeoutMs: row.timeoutMs,
    expectedContentType: row.expectedContentType as AgentDTO["expectedContentType"],
    status: row.status as AgentDTO["status"],
    connectionStatus: row.connectionStatus as AgentDTO["connectionStatus"],
    lastTestedAt: row.lastTestedAt?.toISOString() ?? null,
    lastTestResult,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/suites-shared.ts */
/* ========================================================================== */

/** Shared suite/case validation + DTO mapping. */

export const ruleSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("mustInclude"),
    label: z.string().trim().min(1).max(300),
    value: z.string().min(1).max(300),
  }),
  z.object({
    type: z.literal("mustIncludeAny"),
    label: z.string().trim().min(1).max(300),
    anyOf: z.array(z.string().min(1).max(300)).min(1).max(20),
  }),
  z.object({
    type: z.literal("mustNotInclude"),
    label: z.string().trim().min(1).max(300),
    value: z.string().min(1).max(300),
  }),
  z.object({
    type: z.literal("mustNotIncludeAny"),
    label: z.string().trim().min(1).max(300),
    anyOf: z.array(z.string().min(1).max(300)).min(1).max(20),
  }),
  z.object({
    type: z.literal("mustNotMatch"),
    label: z.string().trim().min(1).max(300),
    pattern: z.string().min(1).max(300),
    flags: z.string().max(10).optional(),
  }),
  z.object({
    type: z.literal("requiredTool"),
    label: z.string().trim().min(1).max(300),
    tool: z.string().trim().min(1).max(100),
    phase: z.enum(["REQUESTED", "OBSERVED", "CONFIRMED"]),
    args: z
      .record(
        z.string().max(60),
        z.object({
          equals: z.string().max(300).optional(),
          contains: z.string().max(300).optional(),
        })
      )
      .optional(),
    before: z.string().trim().max(100).optional(),
  }),
  z.object({
    type: z.literal("forbiddenTool"),
    label: z.string().trim().min(1).max(300),
    tool: z.string().trim().min(1).max(100),
  }),
  z.object({
    type: z.literal("maxToolCalls"),
    label: z.string().trim().min(1).max(300),
    max: z.number().int().min(1).max(100),
  }),
  z.object({
    type: z.literal("claimRequiresConfirmedTool"),
    label: z.string().trim().min(1).max(300),
    claimPattern: z.string().min(1).max(300),
    tool: z.string().trim().min(1).max(100),
  }),
]);

export const testCaseInputSchema = z.object({
  displayId: z
    .string()
    .trim()
    .min(1, "Case id is required.")
    .max(20)
    .regex(/^[A-Za-z0-9][A-Za-z0-9-]*$/, "Case id may contain letters, digits and dashes (e.g. C-11)."),
  category: z.enum(["CORRECTNESS", "TOOL_USAGE", "SAFETY"]),
  severity: z.enum(["CRITICAL", "HIGH", "MEDIUM", "LOW"]),
  title: z.string().trim().min(1, "Title is required.").max(200),
  description: z.string().trim().max(1000).optional().default(""),
  turns: z
    .array(
      z.object({ user: z.string().trim().min(1, "Turn text is required.").max(4000) })
    )
    .min(1, "At least one turn is required.")
    .max(10, "At most 10 turns per case."),
  expectedBehavior: z.string().trim().min(1, "Expected behavior is required.").max(2000),
  evidence: z.string().trim().max(2000).optional().default(""),
  rules: z.array(ruleSchema).max(30).optional().default([]),
  failureHint: z.string().trim().max(1000).optional().nullable(),
  tags: z.array(z.string().trim().min(1).max(40)).max(10).optional().default([]),
});

export const suiteInputSchema = z.object({
  name: z.string().trim().min(1, "Suite name is required.").max(120),
  description: z.string().trim().max(1000).optional().default(""),
  tags: z.array(z.string().trim().min(1).max(40)).max(10).optional().default([]),
});

type SuiteRow = {
  id: string;
  name: string;
  description: string;
  isStarter: boolean;
  tagsCsv: string;
  createdAt: Date;
  updatedAt: Date;
  cases?: unknown;
};

export function mapSuiteSummary(
  row: SuiteRow & { caseCount?: number },
  caseCount?: number
): SuiteSummary {
  const count =
    caseCount ??
    (typeof (row as { _count?: { cases?: number } })._count?.cases === "number"
      ? ((row as { _count?: { cases?: number } })._count!.cases as number)
      : (row.caseCount ?? 0));
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    isStarter: row.isStarter,
    caseCount: count,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function mapCaseRow(row: {
  id: string;
  displayId: string;
  orderIndex: number;
  category: string;
  severity: string;
  title: string;
  description: string;
  turnsJson: string;
  expectedBehavior: string;
  evidenceNote: string;
  rulesJson: string;
  failureHint: string | null;
  tagsCsv: string;
}): TestCaseData {
  return {
    id: row.displayId,
    dbId: row.id,
    order: row.orderIndex,
    category: row.category as TestCaseData["category"],
    severity: row.severity as TestCaseData["severity"],
    title: row.title,
    description: row.description,
    turns: JSON.parse(row.turnsJson || "[]"),
    expectedBehavior: row.expectedBehavior,
    evidence: row.evidenceNote,
    rules: JSON.parse(row.rulesJson || "[]"),
    failureHint: row.failureHint ?? undefined,
    tags: row.tagsCsv ? row.tagsCsv.split(",").filter(Boolean) : [],
  };
}

export async function loadSuiteDetail(
  suiteId: string,
  workspaceId: string
): Promise<SuiteDetail | null> {
  const suite = await db.testSuite.findFirst({
    where: { id: suiteId, workspaceId },
    include: { cases: { orderBy: { orderIndex: "asc" } } },
  });
  if (!suite) return null;
  return {
    id: suite.id,
    name: suite.name,
    description: suite.description,
    isStarter: suite.isStarter,
    caseCount: suite.cases.length,
    createdAt: suite.createdAt.toISOString(),
    updatedAt: suite.updatedAt.toISOString(),
    cases: suite.cases.map(mapCaseRow),
  };
}


/* ========================================================================== */
/* from .zscripts/pristine/lib-backup/server/seed.ts */
/* ========================================================================== */

/**
 * Workspace seeding — every new workspace gets:
 *  1. The demo sandbox agent (internal, no network, clearly labeled)
 *  2. The 25-case starter suite (editable)
 *  3. A SIMULATED SAMPLE run (isSample=true, never mixed with real runs)
 */

export async function seedWorkspace(workspaceId: string, ownerId: string, ownerName: string) {
  /* 1 — demo sandbox agent */
  await db.agent.create({
    data: {
      workspaceId,
      name: "Demo sandbox agent — Retail support",
      description:
        "A fully internal, scripted customer-support agent (\"Trailhead Outfitters\"). It makes no network calls and deliberately contains four realistic flaws so you can explore real evaluation results without connecting a production agent.",
      category: "CUSTOMER_SUPPORT",
      type: "DEMO_SANDBOX",
      endpointUrl: null,
      method: "POST",
      headersJson: "{}",
      bodyTemplate: DEFAULT_BODY_TEMPLATE,
      responseField: "reply",
      toolCallsField: "tool_calls",
      authType: "NONE",
      timeoutMs: 15000,
      expectedContentType: "JSON",
      status: "ACTIVE",
      connectionStatus: "CONNECTED",
      lastTestedAt: new Date(),
      lastTestResultJson: JSON.stringify({
        ok: true,
        statusCode: 200,
        durationMs: 118,
        replyPreview:
          "Hello! This is the Trailhead Outfitters support sandbox. Connection successful — how can I help you today?",
        testedAt: new Date().toISOString(),
        note: "Internal sandbox — no network request was made.",
      }),
    },
  });

  /* 2 — starter suite with 25 cases */
  const suite = await db.testSuite.create({
    data: {
      workspaceId,
      name: STARTER_SUITE_NAME,
      description: STARTER_SUITE_DESCRIPTION,
      isStarter: true,
      tagsCsv: "customer-support,starter",
      cases: {
        create: STARTER_SUITE.map((c) => ({
          displayId: c.id,
          orderIndex: c.order,
          category: c.category,
          severity: c.severity,
          title: c.title,
          description: c.description,
          turnsJson: JSON.stringify(c.turns),
          expectedBehavior: c.expectedBehavior,
          evidenceNote: c.evidence,
          rulesJson: JSON.stringify(c.rules),
          failureHint: c.failureHint ?? null,
          tagsCsv: (c.tags ?? []).join(","),
        })),
      },
    },
  });

  /* 3 — simulated sample run (clearly labeled, isolated from real runs) */
  const sample = buildSampleRunDetail();
  const sampleAgent = await db.agent.findFirst({
    where: { workspaceId, type: "DEMO_SANDBOX" },
    select: { id: true, name: true },
  });

  await db.testRun.create({
    data: {
      workspaceId,
      agentId: sampleAgent!.id,
      suiteId: suite.id,
      agentNameSnapshot: sampleAgent?.name ?? "Demo sandbox agent — Retail support",
      agentTypeSnapshot: "DEMO_SANDBOX",
      suiteNameSnapshot: suite.name,
      status: "COMPLETED",
      isSample: true,
      totalCases: sample.total,
      progress: sample.total,
      passed: sample.passed,
      failed: sample.failed,
      inconclusive: sample.inconclusive,
      errored: sample.errored,
      notExecuted: sample.notExecuted,
      score: sample.score,
      categoriesJson: JSON.stringify(sample.categories),
      createdByUserId: ownerId,
      createdByName: ownerName,
      startedAt: new Date(sample.startedAt),
      completedAt: new Date(sample.completedAt ?? sample.startedAt),
      durationMs: sample.durationMs,
      results: {
        create: sample.results.map((r) => ({
          displayId: r.caseId,
          orderIndex: r.order,
          category: r.category,
          severity: r.severity,
          title: r.title,
          status: r.status,
          explanation: r.explanation,
          recommendation: r.recommendation ?? null,
          observedReply: r.observedReply ?? null,
          expectedBehavior: r.expectedBehavior,
          evidenceNote: r.evidence,
          failureHint: r.failureHint ?? null,
          turnsEvidenceJson: JSON.stringify(r.turns),
          ruleOutcomesJson: JSON.stringify(r.ruleOutcomes),
          durationMs: r.durationMs ?? null,
          caseId: `sample-${r.caseId}`,
          toolEvents: {
            create: (r.toolEvents ?? []).map((e, idx) => ({
              phase: e.phase,
              name: e.name,
              argumentsJson: e.arguments ? JSON.stringify(e.arguments) : null,
              status: e.status,
              resultJson: e.result !== undefined ? JSON.stringify(e.result) : null,
              timestamp: e.timestamp ? new Date(e.timestamp) : null,
              orderIndex: idx,
              turnIndex: e.turn ?? null,
            })),
          },
        })),
      },
    },
  });

  await db.workspace.update({
    where: { id: workspaceId },
    data: { sampleSeeded: true },
  });
}
